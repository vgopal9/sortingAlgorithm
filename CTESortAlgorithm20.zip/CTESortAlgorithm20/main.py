import pandas as pd
import numpy as np


#FORMATTING (skip)
def normalizeSC(listOfList):
	output = []
	lenMax = max(map(len, listOfList))
	#print('maxlength:', str(lenMax))
	for items in listOfList:
		lenCurrent = len(items)
		deficit = lenMax - lenCurrent
		if deficit > 0:
			items = items + (['  '] * deficit)
		else:
			items = [str(item) for item in items]
		output.append(items)
	return output


#reading CTESort file
dataSort = pd.read_csv("CTESort.csv")

#CTESort file made into DataFrame - no format alterations
studentCoursesDF = pd.DataFrame(
    dataSort, columns=['Student Code', 'Grade Level', 'Course #'])

#CTESort DataFrame (DF) - pivoted once clockwise, student code in a row (without repeats)
pivotedStudentCoursesDF = studentCoursesDF.pivot(
    index='Course #',
    columns=['Student Code', 'Grade Level'],
    values='Course #')
#CTESort DF - normalized = pivotedStudentCoursesDF, replaced NaN with 0.0

normalizedStudentCoursesDF = pivotedStudentCoursesDF.replace(np.nan,
                                                             0.0,
                                                             regex=True)
#print(normalizedStudentCoursesDF)
#list of business programs with corresponding course codes
#IMPORTANT: MAKE SURE EACH BUSINESS PROGRAM HAS THE SAME NUMBER OF COURSES, OR ADD "N/A"
businessProgramCourses = {
    'Accounting/Finance':
    [6004, 6370, 6092, 6172, 6232, 6231, 6162, 6372, 6313, 'N/A', 'N/A'],
    'Business Admin. & Entrepreneurship':
    [6004, 6370, 6092, 6232, 6231, 6162, 6372, 6222, 8346, 6125, 6313],
    'Marketing':
    [6004, 6370, 6372, 8346, 6132, 6122, 6313, 'N/A', 'N/A', 'N/A', 'N/A'],
}

#businessProgramCourses list made into DataFrame - no format alterations
businessProgramsDF = pd.DataFrame(businessProgramCourses,
                                  columns=[
                                      'Accounting/Finance',
                                      'Business Admin. & Entrepreneurship',
                                      'Marketing'
                                  ])
#print(businessProgramsDF)
#list of courses in each business program that fit the "OR" conditional (refer to CTE Programs of Study document)
#last value in each list is assigned credit (*assumption:* no course will have codes that 2 digits)
businessProgramConditionals = {
    'Accounting/Finance': [[6232, 6231, 1.0], [6162, 6372, 0.5]],
    'Business Admin. & Entrepreneurship': [[6232, 6231, 1.0],
                                           [6162, 6125, 6092, 0.5]],
    'Marketing': ['N/A', 'N/A'],
}
#list of conditionals made into DataFrame - no format alterations
businessProgramsConditionalsDF = pd.DataFrame(
    businessProgramConditionals,
    columns=[
        'Accounting/Finance', 'Business Admin. & Entrepreneurship', 'Marketing'
    ])
#print(businessProgramsConditionalsDF)
#list of Course Titles with corresponding Course Code
#IMPORTANT: CANNOT BE RANDOM, NEED TO MATCH UP
courseTitles = {
    'Course No': [
        '6004.0', '6370.0', '6092.0', '6172.0', '6232.0', '6231.0', '6162.0',
        '6372.0', '6222.0', '8346.0', '6125.0', '6132.0', '6122.0', '6313.0'
    ],
    'Course Title': [
        'Your Job Your Money', 'Career & Money Skills', 'Personal Finance',
        'Personal Law', 'Accounting', 'College Accounting', 'Corporate Law',
        'Computer Essentials', 'Entrepreneurship', 'Social Media Marketing',
        'Hospitality Mgmt.', 'Sports Marketing', 'Marketing', 'CEIP'
    ],
    'Course Credits': [
        '0.5', '0.5', '0.5', '0.5', '1.0', '1.0', '0.5', '0.5', '0.5', '0.5',
        '0.5', '0.5', '1.0', '0.5'
    ]
}

courseTitlesDF = pd.DataFrame(
    courseTitles, columns=['Course No', 'Course Title', 'Course Credits'])
#print(courseTitlesDF)

#creating empty lists for later use (outside for loop)
output = []
studentCourses = []
print(normalizedStudentCoursesDF)
for student in normalizedStudentCoursesDF:
  #print('Student Code : ' + str(student[0]) + '* G:' + str(student[1]))
  studentCourseClassifiers = []
  studentCourses = []
  #print('****')
  for businessProgram in businessProgramsDF:
    #print('--Business Program Name : ', businessProgram)

		#making a list of each student and which business program each of their courses falls under
    overlap = list(
		    set(businessProgramsDF[businessProgram])
		    & set(normalizedStudentCoursesDF[student]))

    #print('overlap')
    #print("business programs df of "+ businessProgram)
    #print(businessProgramsDF[businessProgram])
    #print("normalized student courses df of student")
    #print(normalizedStudentCoursesDF[student])
    #print(overlap)
#RP STOPPED WORKING HERE##
#************************#
    #print("Student Courses")
    #print(studentCourses)
    studentCourses.append(overlap)
    overlapCopySet = set(overlap.copy())

    conditionalsListBP = businessProgramsConditionalsDF[businessProgram]
    countConditonalCredits = 0.0
		#loop through overlap to find which courses taken fall under "OR" conditional
    for x in conditionalsListBP:
      studentConditionalCoursesSet = set(overlap) & set(x)
      #print('student conditional overlap')
      #print(studentConditionalCoursesSet)

			#if there are (one or more) courses that fit the "OR" conditional, set countConditionalCredits to 1
			#NOTE: setting overlapCopySet to only those classes taken that ** don't ** fit "OR" conditional

			#finding corresponding credit given course code
      if type(x) is list:
        conditionalCredit = x[-1]
      else:
        conditionalCredit = 0.0
      
      if len(studentConditionalCoursesSet) >= 1:
        countConditonalCredits = countConditonalCredits + conditionalCredit
        overlapCopySet = overlapCopySet - studentConditionalCoursesSet
		#print("Credit Count:"+ str(countConditonalCredits + len(overlapCopySet)))

		#print(overlapCopySet)

		#finding total credit for other - non - conditional courses taken
    countOtherCourseCredit = 0.0
    for otherCourseCode in overlapCopySet:
      index = courseTitlesDF[courseTitlesDF['Course No'] == str(
			    otherCourseCode)].index.values
			#print(courseTitlesDF.iloc[index[0]]['Course Credits'])
      countOtherCourseCredit = countOtherCourseCredit + float(
			    courseTitlesDF.iloc[index[0]]['Course Credits'])

		#algorithm
    if countConditonalCredits + countOtherCourseCredit >= 2:
      studentCourseClassifiers.append('(C):  ' +
			                                str(countConditonalCredits +
			                                    countOtherCourseCredit))
    elif countConditonalCredits + countOtherCourseCredit >= 1:
      studentCourseClassifiers.append('(P):  ' +
			                                str(countConditonalCredits +
			                                    countOtherCourseCredit))
    else:
      studentCourseClassifiers.append('(N/A):  ' +
			                                str(countConditonalCredits +
			                                    countOtherCourseCredit))

	#FORMATTING(skip)
  studentCourseClassifiers.insert(0, 'G:' + str(student[1]))
  studentCourseClassifiers.insert(0, student[0])
  output.append(studentCourseClassifiers)

  numpy_array = np.array(normalizeSC(studentCourses))
  transpose = numpy_array.T
  displayTransposedStudentCourses = transpose.tolist()
  for items in displayTransposedStudentCourses:
    items.insert(0, ' ')
    items.insert(0, ' ')
    output.append(items)

businessProgramList = businessProgramsDF.columns.tolist()
businessProgramList.insert(0, studentCoursesDF.columns[1])
businessProgramList.insert(0, studentCoursesDF.columns[0])
resultDF = pd.DataFrame(output, columns=businessProgramList)
#print(courseTitles['Course No'])
#print(courseTitles['Course Title'])
resultDF.replace(courseTitles['Course No'],
                 courseTitles['Course Title'],
                 inplace=True)

studentNames = pd.read_csv("StudentName.csv")
studentNamesDF = pd.DataFrame(studentNames,
                              columns=['Student Code', 'Student Name'])
resultDF.replace(studentNamesDF['Student Code'].tolist(),
                 studentNamesDF['Student Name'].tolist(),
                 inplace=True)
#print(studentNamesDF['student no'].tolist())
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', None)
#print(resultDF)

resultDF.to_csv(r'Results.csv', index=False, header=True)
